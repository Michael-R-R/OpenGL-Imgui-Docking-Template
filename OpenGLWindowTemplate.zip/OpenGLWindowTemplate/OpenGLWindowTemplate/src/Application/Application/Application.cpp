#include "Application.h"

Application::Application(const char* windowTitle) :
	mainWindow(windowTitle),
	currentWindow(mainWindow.getGlfwWindow()),
	interfaceManager(currentWindow, mainWindow.getGlslVersion()),
	inputManager()
{
	setup();
}

Application::~Application()
{

}

void Application::run()
{
	while (!glfwWindowShouldClose(currentWindow))
	{
		inputManager.processInput(currentWindow);

		glClearColor(0.27f, 0.27f, 0.27f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);

		interfaceManager.draw();

		glfwPollEvents();
		glfwSwapBuffers(currentWindow);
	}
}

void Application::shutDown()
{
	interfaceManager.cleanUp();
	glfwDestroyWindow(currentWindow);
	glfwTerminate();
}

void Application::setup()
{
	glfwSetFramebufferSizeCallback(currentWindow, mainWindow.framebufferSizeCallback);
}
