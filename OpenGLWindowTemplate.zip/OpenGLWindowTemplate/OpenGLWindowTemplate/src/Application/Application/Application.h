#pragma once

#include "Application/MainWindow/MainWindow.h"
#include "LargeScaleArchitecture/Interface/InterfaceManager/InterfaceManager.h"
#include "SystemManagers/Input/InputManager/InputManager.h"


class Application
{
	MainWindow mainWindow;
	GLFWwindow* currentWindow;

	InterfaceManager interfaceManager;
	InputManager inputManager;

public:
	Application(const char* windowTitle);
	~Application();

	void run();
	void shutDown();

private:
	void setup();
};

