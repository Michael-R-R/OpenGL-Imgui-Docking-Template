#include "MainWindow.h"

MainWindow::MainWindow(const char* title) :
	width(800),
	height(600),
	windowTitle(title),
	glslVersion("#version 430 core"),
	window(nullptr)
{
	setup();
	setupWindowIcon();
}

MainWindow::~MainWindow()
{

}

void MainWindow::setup()
{
	initGLFW();
	createWindow();
	initGLAD();
}

void MainWindow::initGLFW()
{
	if (!glfwInit())
	{
		std::cerr << "Failed to initalize GLFW" << std::endl;

		return;
	}

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
}

void MainWindow::createWindow()
{
	window = glfwCreateWindow(width, height, windowTitle, nullptr, nullptr);
	if (!window)
	{
		std::cerr << "Failed to create GLFW Window" << std::endl;
		glfwTerminate();

		return;
	}
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1); // enable vsync
}

void MainWindow::initGLAD()
{
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cerr << "Failed to initalize GLAD" << std::endl;
	}
}

void MainWindow::setupWindowIcon()
{
	GLFWimage image;
	image.pixels = stbi_load("resources\\icons\\WindowIcon\\defaultIcon.png", &image.width, &image.height, 0, 4);
	glfwSetWindowIcon(window, 1, &image);
	stbi_image_free(image.pixels);
}
void MainWindow::updateSize(const int w, const int h)
{
	width = w;
	height = h;
}

void MainWindow::framebufferSizeCallback(GLFWwindow* window, int w, int h)
{
	glViewport(0, 0, w, h);
}
