#pragma once

#include <iostream>

#include <glad/glad.h> 
#include <GLFW/glfw3.h>

#include "GeneralServices/FileManager/stb_image/stb_image.h"

class MainWindow
{
	int width;
	int height;

	const char* windowTitle;
	const char* glslVersion;
	GLFWwindow* window;

public:
	MainWindow(const char* title);
	~MainWindow();

private:
	void setup();
	void initGLFW();
	void createWindow();
	void initGLAD();
	void setupWindowIcon();

public:
	void updateSize(const int w, const int h);

	int getWidth() { return width; }
	int getHeight() { return height; }
	const char* getGlslVersion() { return glslVersion; }
	GLFWwindow* getGlfwWindow() { return window;  }

	static void framebufferSizeCallback(GLFWwindow* window, int w, int h);
};

