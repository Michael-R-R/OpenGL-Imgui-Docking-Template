#pragma once

#include "LargeScaleArchitecture/Interface/ImguiHandler/ImguiHandler.h"

class InterfaceManager
{
	ImguiHandler imguiHandler;

public:
	InterfaceManager(GLFWwindow* window, const char* glslVersion);
	~InterfaceManager();

	void draw();
	void cleanUp();
};

