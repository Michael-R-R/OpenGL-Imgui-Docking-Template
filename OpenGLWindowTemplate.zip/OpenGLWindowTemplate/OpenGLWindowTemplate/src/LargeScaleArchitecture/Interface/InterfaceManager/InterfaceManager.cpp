#include "InterfaceManager.h"

InterfaceManager::InterfaceManager(GLFWwindow* window, const char* glslVersion) :
	imguiHandler(window, glslVersion)
{

}

InterfaceManager::~InterfaceManager()
{

}

void InterfaceManager::draw()
{
	imguiHandler.draw();
}

void InterfaceManager::cleanUp()
{
	imguiHandler.cleanUp();
}
