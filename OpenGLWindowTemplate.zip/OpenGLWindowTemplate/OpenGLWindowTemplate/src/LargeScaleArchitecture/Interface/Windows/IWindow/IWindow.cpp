#include "IWindow.h"

IWindow::IWindow() :
	windowTitle(""),
	isShown(true),
	windowFlags()
{

}

void IWindow::update(const bool& isActive)
{
	isShown = isActive;
}

void IWindow::draw()
{
	if (isShown)
	{
		show();
	}
	else
	{
		hide();
	}
}
