#pragma once

#include <iostream>
#include <imgui/imgui.h>

class IWindow
{
protected:
	const char* windowTitle;
	bool isShown;
	ImGuiWindowFlags windowFlags;

	virtual void show() = 0;
	virtual void hide() = 0;
	virtual void drawWidgets() = 0;

public:
	IWindow();
	~IWindow() = default;

	virtual void update(const bool& isActive);
	virtual void draw();
};