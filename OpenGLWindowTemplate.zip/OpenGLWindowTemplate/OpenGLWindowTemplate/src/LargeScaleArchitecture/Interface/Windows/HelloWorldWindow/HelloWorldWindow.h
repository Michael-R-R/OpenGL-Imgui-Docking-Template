#pragma once

#include "LargeScaleArchitecture/Interface/Windows/IWindow/IWindow.h"

class HelloWorldWindow : public IWindow
{
	float sliderValue;
	int counter;
	ImVec4 color;
	
public:
	HelloWorldWindow();
	~HelloWorldWindow();

protected:
	void show() override;
	void hide() override;
	void drawWidgets() override;
};

