#include "HelloWorldWindow.h"

HelloWorldWindow::HelloWorldWindow() :
	sliderValue(0.0f),
	counter(0),
	color(1.0f, 1.0f, 1.0f, 1.0f)
{
	windowTitle = "Hello, World!";
}

HelloWorldWindow::~HelloWorldWindow()
{

}

void HelloWorldWindow::show()
{
	ImGui::Begin(windowTitle);

	drawWidgets();

	ImGui::End();
}

void HelloWorldWindow::hide()
{

}

void HelloWorldWindow::drawWidgets()
{
	ImGui::Text("This is some useful text.");

	ImGui::SliderFloat("float", &sliderValue, 0.0f, 1.0f);

	if (ImGui::Button("Button")) { counter++; }

	ImGui::SameLine();

	ImGui::Text("counter = %d", counter);

	ImGui::ColorPicker4("Color picker", (float*)&color);
}
