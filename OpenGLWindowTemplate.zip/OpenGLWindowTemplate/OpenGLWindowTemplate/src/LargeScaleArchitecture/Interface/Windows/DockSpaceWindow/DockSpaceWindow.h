#pragma once

#include "LargeScaleArchitecture/Interface/Windows/IWindow/IWindow.h"

#include "LargeScaleArchitecture/Interface/Widgets/DockspaceMenuBarWidget/DockspaceMenuBarWidget.h"

class DockSpaceWindow : public IWindow
{
	ImGuiDockNodeFlags dockspaceFlags;
	
	DockspaceMenuBarWidget menuBar;

public:
	DockSpaceWindow();
	~DockSpaceWindow();

	bool getIsHelloWorldShown() { return menuBar.getIsHelloWorldShown(); }

protected:
	void show() override;
	void hide() override;
	void drawWidgets() override;

private:
	void setupViewport();
	void updateDockspace();
};

