#include "DockSpaceWindow.h"

DockSpaceWindow::DockSpaceWindow() :
	dockspaceFlags(ImGuiDockNodeFlags_PassthruCentralNode),
	menuBar()
{
	windowTitle = "Dock Space";
	windowFlags |= ImGuiWindowFlags_MenuBar | ImGuiWindowFlags_NoBackground;
	windowFlags |= ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse;
	windowFlags |= ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove;
	windowFlags |= ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNavFocus;
}

DockSpaceWindow::~DockSpaceWindow()
{

}

void DockSpaceWindow::show()
{
	setupViewport();

	ImGui::Begin(windowTitle, nullptr, windowFlags);

	updateDockspace();

	drawWidgets();

	ImGui::End();
}

void DockSpaceWindow::hide()
{

}

void DockSpaceWindow::drawWidgets()
{
	menuBar.draw();
}

void DockSpaceWindow::setupViewport()
{
	const ImGuiViewport* viewport = ImGui::GetMainViewport();
	ImGui::SetNextWindowPos(viewport->WorkPos);
	ImGui::SetNextWindowSize(viewport->WorkSize);
	ImGui::SetNextWindowViewport(viewport->ID);
}

void DockSpaceWindow::updateDockspace()
{
	ImGuiIO& io = ImGui::GetIO();
	if (io.ConfigFlags & ImGuiConfigFlags_DockingEnable)
	{
		ImGuiID dockspaceId = ImGui::GetID("MyDockSpace");
		ImGui::DockSpace(dockspaceId, ImVec2(0.0f, 0.0f), dockspaceFlags);
	}
}

