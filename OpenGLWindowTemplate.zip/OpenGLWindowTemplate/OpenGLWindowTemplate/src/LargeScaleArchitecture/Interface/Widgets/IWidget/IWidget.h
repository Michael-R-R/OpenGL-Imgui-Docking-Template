#pragma once

#include <iostream>
#include <imgui/imgui.h>

class IWidget
{
protected:
	const char* title;

public:
	IWidget();
	~IWidget() = default;

	virtual void draw() = 0;
};

