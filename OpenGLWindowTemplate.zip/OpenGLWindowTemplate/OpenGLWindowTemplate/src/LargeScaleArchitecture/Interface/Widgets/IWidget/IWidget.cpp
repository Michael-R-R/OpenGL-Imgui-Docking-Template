#include "IWidget.h"

IWidget::IWidget() :
	title("Default")
{

}
