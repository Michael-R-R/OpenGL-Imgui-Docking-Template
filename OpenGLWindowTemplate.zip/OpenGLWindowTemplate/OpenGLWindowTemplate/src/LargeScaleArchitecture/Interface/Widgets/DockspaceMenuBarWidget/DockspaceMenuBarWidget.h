#pragma once

#include "LargeScaleArchitecture/Interface/Widgets/IWidget/IWidget.h"

class DockspaceMenuBarWidget : public IWidget
{
	bool isHelloWorldShown;

public:
	DockspaceMenuBarWidget();
	~DockspaceMenuBarWidget();

	void draw() override;

	bool getIsHelloWorldShown() { return isHelloWorldShown; }
};

