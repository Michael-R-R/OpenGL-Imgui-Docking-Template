#include "DockspaceMenuBarWidget.h"

DockspaceMenuBarWidget::DockspaceMenuBarWidget() :
	isHelloWorldShown(true)
{

}

DockspaceMenuBarWidget::~DockspaceMenuBarWidget()
{

}

void DockspaceMenuBarWidget::draw()
{
	if (ImGui::BeginMenuBar())
	{
		if (ImGui::BeginMenu("Windows"))
		{
			ImGui::MenuItem("Show Hello World", nullptr, &isHelloWorldShown);
			ImGui::Separator();
			ImGui::EndMenu();
		}

		ImGui::EndMenuBar();
	}
}
