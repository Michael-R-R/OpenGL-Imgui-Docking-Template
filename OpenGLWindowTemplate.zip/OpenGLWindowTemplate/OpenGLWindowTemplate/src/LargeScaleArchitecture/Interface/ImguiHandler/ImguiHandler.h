#pragma once

#include <GLFW/glfw3.h>

#include "LargeScaleArchitecture/Interface/ImguiContext/ImguiContext.h"
#include "LargeScaleArchitecture/Interface/ImguiStyle/ImguiStyle.h"

#include "LargeScaleArchitecture/Interface/Windows/DockSpaceWindow/DockSpaceWindow.h"
#include "LargeScaleArchitecture/Interface/Windows/HelloWorldWindow/HelloWorldWindow.h"

class ImguiHandler
{
	ImguiContext context;
	ImguiStyle style;

	DockSpaceWindow dockSpaceWindow;
	HelloWorldWindow helloWorldWindow;

public:
	ImguiHandler(GLFWwindow* window, const char* glslVersion);
	~ImguiHandler();

private:
	void setup(GLFWwindow* window, const char* glslVersion);
	
public:
	void draw();
	void cleanUp();

private:
	void updateWindows();
	void startNewFrame();
	void renderFrame();
	void updateOpenglContext();
};

