#include "ImguiHandler.h"

ImguiHandler::ImguiHandler(GLFWwindow* window, const char* glslVersion) :
	context(),
	style(),
	dockSpaceWindow(),
	helloWorldWindow()
{
	setup(window, glslVersion);
}

ImguiHandler::~ImguiHandler()
{

}

void ImguiHandler::setup(GLFWwindow* window, const char* glslVersion)
{
	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init(glslVersion);
}

void ImguiHandler::draw()
{
	updateWindows();

	startNewFrame();

	// --- Windows start here --- //
	dockSpaceWindow.draw();
	helloWorldWindow.draw();
	// --- Windows end here --- //

	renderFrame();

	updateOpenglContext();
}

void ImguiHandler::cleanUp()
{
	ImGui_ImplOpenGL3_Shutdown();
	ImGui_ImplGlfw_Shutdown();
	ImGui::DestroyContext();
}

void ImguiHandler::updateWindows()
{
	helloWorldWindow.update(dockSpaceWindow.getIsHelloWorldShown());
}

void ImguiHandler::startNewFrame()
{
	ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplGlfw_NewFrame();
	ImGui::NewFrame();
}

void ImguiHandler::renderFrame()
{
	ImGui::Render();
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

void ImguiHandler::updateOpenglContext()
{
	if (ImGui::GetIO().ConfigFlags & ImGuiConfigFlags_ViewportsEnable)
	{
		GLFWwindow* backupCurrentContext = glfwGetCurrentContext();
		ImGui::UpdatePlatformWindows();
		ImGui::RenderPlatformWindowsDefault();
		glfwMakeContextCurrent(backupCurrentContext);
	}
}
