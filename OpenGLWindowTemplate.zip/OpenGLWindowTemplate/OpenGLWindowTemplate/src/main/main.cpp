#include "Application/Application/Application.h"

// IMPORTANT: Remember to add the lib folder that has the glfw3.lib 
// to the 'required' folder, otherwise the application won't run

int main()
{
	Application application("Window Title Here");

	application.run(); // Run until the while loop exits
	application.shutDown(); // Clean up before shut down

	return 0;
}
